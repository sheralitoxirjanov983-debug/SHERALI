// ===================== STORAGE HELPERS =====================
// Ma'lumotlar window.storage orqali saqlanadi (shared=true -> barcha qurilmalar ko'radi)
const SHARED = true;

async function loadData(key, fallback) {
  try {
    const res = await window.storage.get(key, SHARED);
    return res ? JSON.parse(res.value) : fallback;
  } catch (e) {
    return fallback;
  }
}
async function saveData(key, value) {
  try {
    await window.storage.set(key, JSON.stringify(value), SHARED);
  } catch (e) {
    console.error('Saqlashda xato:', e);
    showToast('Saqlashda xatolik yuz berdi');
  }
}

// In-memory state
let products = [];   // {id, name, code, cost, price, qty, min}
let workers = [];    // {id, name, phone, percent}
let sales = [];       // {id, productId, productName, qty, price, total, workerId, workerName, date, type:'sale'|'qarz', customerName, customerPhone, dueDays, dueDate, paid}
let nextId = 1;

function genId() {
  return (nextId++).toString(36) + Date.now().toString(36);
}

// ===================== INIT =====================
async function init() {
  products = await loadData('products', []);
  workers = await loadData('workers', []);
  sales = await loadData('sales', []);

  bindNav();
  bindModals();
  bindProductPage();
  bindSellPage();
  bindWorkerPage();
  bindDebtPage();
  bindScanner();

  renderAll();
  checkDueDebtsAndNotify();
}
document.addEventListener('DOMContentLoaded', init);

function renderAll() {
  renderDashboard();
  renderProducts();
  renderSellSelectors();
  renderRecentSales();
  renderDebts();
  renderWorkers();
}

// ===================== TOAST =====================
let toastTimer;
function showToast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 2600);
}

// ===================== NUMBER FORMAT =====================
function fmt(num) {
  num = Math.round(num || 0);
  return num.toLocaleString('ru-RU') + " so'm";
}
function fmtNum(num) {
  return Math.round(num || 0).toLocaleString('ru-RU');
}

// ===================== NAVIGATION =====================
function bindNav() {
  document.querySelectorAll('nav.tabs button').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('nav.tabs button').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById('page-' + btn.dataset.page).classList.add('active');
      if (btn.dataset.page === 'dashboard') renderDashboard();
      if (btn.dataset.page === 'debts') renderDebts();
      if (btn.dataset.page === 'workers') renderWorkers();
    });
  });
}

// ===================== MODALS =====================
function bindModals() {
  document.querySelectorAll('[data-close]').forEach(btn => {
    btn.addEventListener('click', () => closeModal(btn.dataset.close));
  });
  document.querySelectorAll('.modal-overlay').forEach(ov => {
    ov.addEventListener('click', (e) => {
      if (e.target === ov) closeModal(ov.id);
    });
  });
}
function openModal(id) {
  document.getElementById(id).classList.add('show');
}
function closeModal(id) {
  document.getElementById(id).classList.remove('show');
  if (id === 'modal-scanner') stopScanner();
}

// ===================== DASHBOARD =====================
function renderDashboard() {
  // total stock value & item count
  let totalValue = 0, totalItems = products.length;
  products.forEach(p => totalValue += (p.price * p.qty));
  document.getElementById('dash-total-value').textContent = fmt(totalValue);
  document.getElementById('dash-total-items').textContent = totalItems;

  // this month stats
  const now = new Date();
  const monthSales = sales.filter(s => {
    const d = new Date(s.date);
    return d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth();
  });
  let monthRevenue = 0, monthProfit = 0;
  monthSales.forEach(s => {
    monthRevenue += s.total;
    const prod = products.find(p => p.id === s.productId);
    const cost = (s.cost !== undefined ? s.cost : (prod ? prod.cost : 0));
    monthProfit += (s.price - cost) * s.qty - (s.workerCommission || 0);
  });
  document.getElementById('dash-month-sales').textContent = fmt(monthRevenue);
  document.getElementById('dash-month-profit').textContent = fmt(monthProfit);

  // top products (all-time, by qty sold)
  const counts = {};
  sales.forEach(s => {
    if (!counts[s.productId]) counts[s.productId] = { name: s.productName, qty: 0, total: 0 };
    counts[s.productId].qty += s.qty;
    counts[s.productId].total += s.total;
  });
  const top = Object.values(counts).sort((a, b) => b.qty - a.qty).slice(0, 5);
  const topEl = document.getElementById('dash-top-products');
  if (top.length === 0) {
    topEl.innerHTML = '<div class="empty">Hozircha sotuv yo\'q</div>';
  } else {
    topEl.innerHTML = top.map((t, i) => `
      <div class="item-row" style="background:transparent; border:none; padding:8px 0; ${i < top.length-1 ? 'border-bottom:1px solid var(--line);' : ''} border-radius:0;">
        <div class="info">
          <div class="name">${i+1}. ${escapeHtml(t.name)}</div>
          <div class="sub">Sotilgan: ${fmtNum(t.qty)} dona</div>
        </div>
        <div class="right">
          <div class="price">${fmt(t.total)}</div>
        </div>
      </div>
    `).join('');
  }

  // low stock
  const low = products.filter(p => p.qty <= p.min);
  const lowEl = document.getElementById('dash-low-stock');
  if (low.length === 0) {
    lowEl.innerHTML = '<div class="empty">Barcha tovarlar yetarli miqdorda</div>';
  } else {
    lowEl.innerHTML = low.map((p, i) => `
      <div class="item-row" style="background:transparent; border:none; padding:8px 0; ${i < low.length-1 ? 'border-bottom:1px solid var(--line);' : ''} border-radius:0;">
        <div class="info">
          <div class="name">${escapeHtml(p.name)}</div>
          <div class="sub">Chegarasi: ${fmtNum(p.min)} dona</div>
        </div>
        <div class="right">
          <span class="badge low">${fmtNum(p.qty)} dona qoldi</span>
        </div>
      </div>
    `).join('');
  }

  // debts due today/soon
  const todayStr = dateToStr(new Date());
  const activeDebts = sales.filter(s => s.type === 'qarz' && !s.paid);
  const dueSoon = activeDebts.filter(s => {
    const diff = daysBetween(todayStr, s.dueDate);
    return diff <= 1;
  }).sort((a,b) => new Date(a.dueDate) - new Date(b.dueDate));

  const debtEl = document.getElementById('dash-debts-today');
  if (dueSoon.length === 0) {
    debtEl.innerHTML = '<div class="empty">Bugun yoki ertaga muddati tugaydigan nasiya yo\'q</div>';
  } else {
    debtEl.innerHTML = dueSoon.map((s, i) => {
      const diff = daysBetween(todayStr, s.dueDate);
      const label = diff < 0 ? `${Math.abs(diff)} kun kechikkan` : (diff === 0 ? 'Bugun' : 'Ertaga');
      return `
      <div class="item-row" style="background:transparent; border:none; padding:8px 0; ${i < dueSoon.length-1 ? 'border-bottom:1px solid var(--line);' : ''} border-radius:0;" onclick="showDebtDetail('${s.id}')">
        <div class="info">
          <div class="name">${escapeHtml(s.customerName)}</div>
          <div class="sub">${escapeHtml(s.productName)} &bull; ${escapeHtml(s.customerPhone)}</div>
        </div>
        <div class="right">
          <div class="price">${fmt(s.total)}</div>
          <span class="badge ${diff < 0 ? 'low' : 'warn'}">${label}</span>
        </div>
      </div>
    `}).join('');
  }
}

// ===================== PRODUCTS PAGE =====================
function bindProductPage() {
  document.getElementById('btn-add-product').addEventListener('click', () => openProductModal());
  document.getElementById('btn-save-product').addEventListener('click', saveProduct);
  document.getElementById('btn-delete-product').addEventListener('click', deleteProduct);
  document.getElementById('product-search').addEventListener('input', renderProducts);
  document.getElementById('btn-scan-product').addEventListener('click', () => {
    openScanner((code) => {
      const existing = products.find(p => p.code === code);
      if (existing) {
        openProductModal(existing);
      } else {
        openProductModal();
        document.getElementById('product-code').value = code;
        showToast('Yangi kod topildi, tovar ma\'lumotlarini kiriting');
      }
    });
  });
  document.getElementById('btn-scan-in-product').addEventListener('click', () => {
    openScanner((code) => {
      document.getElementById('product-code').value = code;
    });
  });
}

function openProductModal(product) {
  document.getElementById('product-modal-title').textContent = product ? 'Tovarni tahrirlash' : 'Yangi tovar';
  document.getElementById('product-id').value = product ? product.id : '';
  document.getElementById('product-name').value = product ? product.name : '';
  document.getElementById('product-code').value = product ? (product.code || '') : '';
  document.getElementById('product-cost').value = product ? product.cost : '';
  document.getElementById('product-price').value = product ? product.price : '';
  document.getElementById('product-qty').value = product ? product.qty : '';
  document.getElementById('product-min').value = product ? product.min : 5;
  document.getElementById('btn-delete-product').style.display = product ? 'block' : 'none';
  openModal('modal-product');
}

async function saveProduct() {
  const id = document.getElementById('product-id').value;
  const name = document.getElementById('product-name').value.trim();
  const code = document.getElementById('product-code').value.trim();
  const cost = parseFloat(document.getElementById('product-cost').value) || 0;
  const price = parseFloat(document.getElementById('product-price').value) || 0;
  const qty = parseFloat(document.getElementById('product-qty').value) || 0;
  const min = parseFloat(document.getElementById('product-min').value) || 0;

  if (!name) { showToast('Tovar nomini kiriting'); return; }

  if (id) {
    const p = products.find(x => x.id === id);
    Object.assign(p, { name, code, cost, price, qty, min });
  } else {
    products.push({ id: genId(), name, code, cost, price, qty, min });
  }
  await saveData('products', products);
  closeModal('modal-product');
  renderProducts();
  renderSellSelectors();
  renderDashboard();
  showToast('Saqlandi');
}

async function deleteProduct() {
  const id = document.getElementById('product-id').value;
  if (!confirm('Tovarni o\'chirishni tasdiqlaysizmi?')) return;
  products = products.filter(p => p.id !== id);
  await saveData('products', products);
  closeModal('modal-product');
  renderProducts();
  renderSellSelectors();
  renderDashboard();
  showToast('O\'chirildi');
}

function renderProducts() {
  const search = document.getElementById('product-search').value.toLowerCase().trim();
  const list = document.getElementById('products-list');
  let filtered = products;
  if (search) {
    filtered = products.filter(p =>
      p.name.toLowerCase().includes(search) ||
      (p.code || '').toLowerCase().includes(search)
    );
  }
  if (filtered.length === 0) {
    list.innerHTML = '<div class="empty"><i class="ti ti-box-seam"></i>Tovarlar topilmadi</div>';
    return;
  }
  filtered = [...filtered].sort((a,b) => a.name.localeCompare(b.name, 'uz'));
  list.innerHTML = filtered.map(p => {
    const low = p.qty <= p.min;
    return `
    <div class="item-row" onclick="openProductModal(${JSON.stringify(p).replace(/"/g, '&quot;')})">
      <div class="info">
        <div class="name">${escapeHtml(p.name)}</div>
        <div class="sub">${p.code ? 'Kod: ' + escapeHtml(p.code) : 'Kod yo\'q'} &bull; Narx: ${fmt(p.price)}</div>
      </div>
      <div class="right">
        <div class="price">${low ? `<span class="badge low">${fmtNum(p.qty)} dona</span>` : `<span class="badge ok">${fmtNum(p.qty)} dona</span>`}</div>
        <button class="btn secondary small" style="margin-top:6px;" onclick="event.stopPropagation(); showProductQR('${p.id}')"><i class="ti ti-qrcode"></i></button>
      </div>
    </div>
  `}).join('');
}

function showProductQR(id) {
  const p = products.find(x => x.id === id);
  if (!p) return;
  if (!p.code) {
    showToast('Bu tovarda kod yo\'q. Avval kod kiriting.');
    return;
  }
  document.getElementById('qr-show-title').textContent = p.name;
  document.getElementById('qr-show-code').textContent = 'Kod: ' + p.code;
  const wrap = document.getElementById('qr-canvas-wrap');
  wrap.innerHTML = '';
  new QRCode(wrap, {
    text: p.code,
    width: 200,
    height: 200,
    colorDark: '#2C2C2A',
    colorLight: '#ffffff'
  });
  openModal('modal-qr-show');
}

// ===================== SELL PAGE =====================
let sellMode = 'qoldiq';

function bindSellPage() {
  document.querySelectorAll('[data-sell-mode]').forEach(btn => {
    btn.addEventListener('click', () => {
      sellMode = btn.dataset.sellMode;
      document.querySelectorAll('[data-sell-mode]').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById('qarz-fields').style.display = sellMode === 'qarz' ? 'block' : 'none';
      document.getElementById('sell-total-label').textContent = sellMode === 'qarz' ? 'Jami nasiya summasi' : 'Jami summa';
      document.getElementById('btn-confirm-sell').textContent = sellMode === 'qarz' ? 'Nasiyani ro\'yxatga olish' : 'Sotuvni tasdiqlash';
    });
  });

  document.getElementById('sell-product').addEventListener('change', () => {
    const p = products.find(x => x.id === document.getElementById('sell-product').value);
    if (p) document.getElementById('sell-price').value = p.price;
    updateSellTotal();
  });
  document.getElementById('sell-qty').addEventListener('input', updateSellTotal);
  document.getElementById('sell-price').addEventListener('input', updateSellTotal);

  document.getElementById('btn-confirm-sell').addEventListener('click', confirmSell);

  document.getElementById('btn-scan-sell').addEventListener('click', () => {
    openScanner((code) => {
      const p = products.find(x => x.code === code);
      if (p) {
        document.getElementById('sell-product').value = p.id;
        document.getElementById('sell-price').value = p.price;
        updateSellTotal();
        showToast('Tovar topildi: ' + p.name);
      } else {
        showToast('Bu kod bo\'yicha tovar topilmadi');
      }
    });
  });
}

function renderSellSelectors() {
  const sel = document.getElementById('sell-product');
  const current = sel.value;
  sel.innerHTML = products.map(p => `<option value="${p.id}">${escapeHtml(p.name)} (${fmtNum(p.qty)} dona)</option>`).join('');
  if (current && products.find(p => p.id === current)) sel.value = current;
  if (sel.value) {
    const p = products.find(x => x.id === sel.value);
    if (p && !document.getElementById('sell-price').value) document.getElementById('sell-price').value = p.price;
  }

  const wsel = document.getElementById('sell-worker');
  const wcurrent = wsel.value;
  wsel.innerHTML = '<option value="">Hodimsiz / o\'zim</option>' + workers.map(w => `<option value="${w.id}">${escapeHtml(w.name)}</option>`).join('');
  if (wcurrent) wsel.value = wcurrent;

  updateSellTotal();
}

function updateSellTotal() {
  const qty = parseFloat(document.getElementById('sell-qty').value) || 0;
  const price = parseFloat(document.getElementById('sell-price').value) || 0;
  document.getElementById('sell-total').textContent = fmt(qty * price);
}

async function confirmSell() {
  const productId = document.getElementById('sell-product').value;
  const qty = parseFloat(document.getElementById('sell-qty').value) || 0;
  const price = parseFloat(document.getElementById('sell-price').value) || 0;
  const workerId = document.getElementById('sell-worker').value;

  if (!productId) { showToast('Tovarni tanlang'); return; }
  if (qty <= 0) { showToast('Miqdorni kiriting'); return; }
  if (price < 0) { showToast('Narxni kiriting'); return; }

  const product = products.find(p => p.id === productId);
  if (!product) { showToast('Tovar topilmadi'); return; }
  if (qty > product.qty) { showToast(`Omborda yetarli emas. Qoldiq: ${fmtNum(product.qty)} dona`); return; }

  const worker = workers.find(w => w.id === workerId);
  const total = qty * price;
  const commission = worker ? total * (worker.percent / 100) : 0;

  let sale = {
    id: genId(),
    productId: product.id,
    productName: product.name,
    cost: product.cost,
    qty, price, total,
    workerId: worker ? worker.id : '',
    workerName: worker ? worker.name : '',
    workerCommission: commission,
    date: new Date().toISOString(),
    type: sellMode
  };

  if (sellMode === 'qarz') {
    const customerName = document.getElementById('sell-customer-name').value.trim();
    const customerPhone = document.getElementById('sell-customer-phone').value.trim();
    const dueDays = parseInt(document.getElementById('sell-due-days').value) || 0;
    if (!customerName) { showToast('Mijoz ismini kiriting'); return; }
    if (!customerPhone) { showToast('Mijoz telefon raqamini kiriting'); return; }
    if (dueDays <= 0) { showToast('Necha kunga ekanini kiriting'); return; }

    const due = new Date();
    due.setDate(due.getDate() + dueDays);
    sale.customerName = customerName;
    sale.customerPhone = customerPhone;
    sale.dueDays = dueDays;
    sale.dueDate = dateToStr(due);
    sale.paid = false;
  }

  // reduce stock
  product.qty -= qty;
  sales.push(sale);

  await saveData('products', products);
  await saveData('sales', sales);

  // reset form
  document.getElementById('sell-qty').value = 1;
  if (sellMode === 'qarz') {
    document.getElementById('sell-customer-name').value = '';
    document.getElementById('sell-customer-phone').value = '';
    document.getElementById('sell-due-days').value = '';
  }

  renderProducts();
  renderSellSelectors();
  renderDashboard();
  renderRecentSales();
  renderDebts();
  renderWorkers();

  showToast(sellMode === 'qarz' ? 'Nasiya ro\'yxatga olindi' : 'Sotuv saqlandi');
}

function renderRecentSales() {
  const list = document.getElementById('recent-sales');
  const recent = [...sales].sort((a,b) => new Date(b.date) - new Date(a.date)).slice(0, 10);
  if (recent.length === 0) {
    list.innerHTML = '<div class="empty"><i class="ti ti-receipt"></i>Hozircha sotuvlar yo\'q</div>';
    return;
  }
  list.innerHTML = recent.map(s => `
    <div class="item-row">
      <div class="info">
        <div class="name">${escapeHtml(s.productName)} &times; ${fmtNum(s.qty)}</div>
        <div class="sub">${formatDateTime(s.date)} ${s.workerName ? '&bull; ' + escapeHtml(s.workerName) : ''} ${s.type === 'qarz' ? '&bull; Nasiya' : ''}</div>
      </div>
      <div class="right">
        <div class="price">${fmt(s.total)}</div>
        ${s.type === 'qarz' ? `<span class="badge ${s.paid ? 'ok' : 'warn'}">${s.paid ? 'To\'langan' : 'Nasiya'}</span>` : ''}
      </div>
    </div>
  `).join('');
}

// ===================== WORKERS PAGE =====================
let workerPeriod = 'month';

function bindWorkerPage() {
  document.getElementById('btn-add-worker').addEventListener('click', () => openWorkerModal());
  document.getElementById('btn-save-worker').addEventListener('click', saveWorker);
  document.getElementById('btn-delete-worker').addEventListener('click', deleteWorker);

  document.querySelectorAll('[data-worker-period]').forEach(btn => {
    btn.addEventListener('click', () => {
      workerPeriod = btn.dataset.workerPeriod;
      document.querySelectorAll('[data-worker-period]').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      renderWorkers();
    });
  });
}

function openWorkerModal(worker) {
  document.getElementById('worker-modal-title').textContent = worker ? 'Hodimni tahrirlash' : 'Yangi hodim';
  document.getElementById('worker-id').value = worker ? worker.id : '';
  document.getElementById('worker-name').value = worker ? worker.name : '';
  document.getElementById('worker-phone').value = worker ? worker.phone : '';
  document.getElementById('worker-percent').value = worker ? worker.percent : 5;
  document.getElementById('btn-delete-worker').style.display = worker ? 'block' : 'none';
  openModal('modal-worker');
}

async function saveWorker() {
  const id = document.getElementById('worker-id').value;
  const name = document.getElementById('worker-name').value.trim();
  const phone = document.getElementById('worker-phone').value.trim();
  const percent = parseFloat(document.getElementById('worker-percent').value) || 0;

  if (!name) { showToast('Hodim ismini kiriting'); return; }

  if (id) {
    const w = workers.find(x => x.id === id);
    Object.assign(w, { name, phone, percent });
  } else {
    workers.push({ id: genId(), name, phone, percent });
  }
  await saveData('workers', workers);
  closeModal('modal-worker');
  renderWorkers();
  renderSellSelectors();
  showToast('Saqlandi');
}

async function deleteWorker() {
  const id = document.getElementById('worker-id').value;
  if (!confirm('Hodimni o\'chirishni tasdiqlaysizmi?')) return;
  workers = workers.filter(w => w.id !== id);
  await saveData('workers', workers);
  closeModal('modal-worker');
  renderWorkers();
  renderSellSelectors();
  showToast('O\'chirildi');
}

function renderWorkers() {
  const list = document.getElementById('workers-list');
  if (workers.length === 0) {
    list.innerHTML = '<div class="empty"><i class="ti ti-users"></i>Hozircha hodimlar yo\'q</div>';
    return;
  }

  const now = new Date();
  list.innerHTML = workers.map(w => {
    let relevantSales = sales.filter(s => s.workerId === w.id);
    if (workerPeriod === 'month') {
      relevantSales = relevantSales.filter(s => {
        const d = new Date(s.date);
        return d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth();
      });
    }
    const totalSold = relevantSales.reduce((sum, s) => sum + s.total, 0);
    const totalQty = relevantSales.reduce((sum, s) => sum + s.qty, 0);
    const commission = relevantSales.reduce((sum, s) => sum + (s.workerCommission || 0), 0);

    return `
    <div class="card worker-card" onclick="openWorkerModal(${JSON.stringify(w).replace(/"/g, '&quot;')})">
      <div class="row1">
        <span class="name">${escapeHtml(w.name)}</span>
        <span class="pct">${w.percent}% komissiya</span>
      </div>
      <div class="row2">
        <span>Sotgan: <b>${fmtNum(totalQty)} dona</b></span>
        <span>Summa: <b>${fmt(totalSold)}</b></span>
      </div>
      <div class="row2" style="margin-top:4px;">
        <span>${escapeHtml(w.phone || 'Telefon yo\'q')}</span>
        <span>Olishi: <b>${fmt(commission)}</b></span>
      </div>
    </div>
  `}).join('');
}

// ===================== DEBTS PAGE =====================
let debtFilter = 'active';

function bindDebtPage() {
  document.querySelectorAll('[data-debt-filter]').forEach(btn => {
    btn.addEventListener('click', () => {
      debtFilter = btn.dataset.debtFilter;
      document.querySelectorAll('[data-debt-filter]').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      renderDebts();
    });
  });
}

function renderDebts() {
  const list = document.getElementById('debts-list');
  let debts = sales.filter(s => s.type === 'qarz');
  if (debtFilter === 'active') debts = debts.filter(s => !s.paid);
  else debts = debts.filter(s => s.paid);

  debts = debts.sort((a,b) => new Date(a.dueDate) - new Date(b.dueDate));

  if (debts.length === 0) {
    list.innerHTML = `<div class="empty"><i class="ti ti-credit-card"></i>${debtFilter === 'active' ? 'Faol nasiyalar yo\'q' : 'To\'langan nasiyalar yo\'q'}</div>`;
    return;
  }

  const todayStr = dateToStr(new Date());
  list.innerHTML = debts.map(s => {
    let rowClass = 'item-row';
    let badge = '';
    if (!s.paid) {
      const diff = daysBetween(todayStr, s.dueDate);
      if (diff < 0) { rowClass += ' due-today'; badge = `<span class="badge low">${Math.abs(diff)} kun kechikkan</span>`; }
      else if (diff === 0) { rowClass += ' due-today'; badge = `<span class="badge low">Bugun muddati</span>`; }
      else if (diff <= 2) { rowClass += ' due-soon'; badge = `<span class="badge warn">${diff} kun qoldi</span>`; }
      else { badge = `<span class="badge warn">${diff} kun qoldi</span>`; }
    } else {
      badge = `<span class="badge ok">To'langan</span>`;
    }
    return `
    <div class="${rowClass}" onclick="showDebtDetail('${s.id}')">
      <div class="info">
        <div class="name">${escapeHtml(s.customerName)}</div>
        <div class="sub">${escapeHtml(s.productName)} &times; ${fmtNum(s.qty)} &bull; Muddat: ${formatDate(s.dueDate)}</div>
      </div>
      <div class="right">
        <div class="price">${fmt(s.total)}</div>
        ${badge}
      </div>
    </div>
  `}).join('');
}

function showDebtDetail(saleId) {
  const s = sales.find(x => x.id === saleId);
  if (!s) return;
  const todayStr = dateToStr(new Date());
  const diff = daysBetween(todayStr, s.dueDate);
  let statusText = '';
  if (s.paid) statusText = 'To\'langan';
  else if (diff < 0) statusText = `${Math.abs(diff)} kun kechikkan`;
  else if (diff === 0) statusText = 'Bugun muddati tugaydi';
  else statusText = `${diff} kun qoldi`;

  const smsText = encodeURIComponent(
    `Hurmatli ${s.customerName}, "${s.productName}" tovari uchun nasiya muddati ${s.paid ? 'tugagan' : (diff <= 0 ? 'bugun tugaydi' : diff + ' kundan keyin tugaydi')}. Summa: ${fmtNum(s.total)} so'm. Iltimos, to'lovni amalga oshiring.`
  );
  const phoneDigits = (s.customerPhone || '').replace(/[^\d+]/g, '');

  document.getElementById('debt-detail-body').innerHTML = `
    <div class="card">
      <div class="field"><label>Mijoz</label><div style="font-size:15px; font-weight:500;">${escapeHtml(s.customerName)}</div></div>
      <div class="field"><label>Telefon</label><div style="font-size:15px;">${escapeHtml(s.customerPhone)}</div></div>
      <div class="field"><label>Tovar</label><div style="font-size:15px;">${escapeHtml(s.productName)} &times; ${fmtNum(s.qty)}</div></div>
      <div class="field"><label>Summa</label><div style="font-size:18px; font-weight:600;">${fmt(s.total)}</div></div>
      <div class="field"><label>Berilgan sana</label><div style="font-size:15px;">${formatDate(s.date)}</div></div>
      <div class="field"><label>Qaytarish muddati</label><div style="font-size:15px;">${formatDate(s.dueDate)} (${s.dueDays} kun) &bull; ${statusText}</div></div>
    </div>
    <div class="btn-row" style="margin-bottom:10px;">
      <a class="btn secondary" href="sms:${phoneDigits}?body=${smsText}" style="text-decoration:none;"><i class="ti ti-message"></i> SMS yuborish</a>
      <a class="btn secondary" href="tel:${phoneDigits}" style="text-decoration:none; max-width:50px; flex:0 0 50px;"><i class="ti ti-phone"></i></a>
    </div>
    ${!s.paid ? `<button class="btn" onclick="markDebtPaid('${s.id}')">To'landi deb belgilash</button>` : ''}
    <p class="muted-small">SMS tugmasi telefoningizning standart SMS ilovasini ochadi, xabar matni avtomatik tayyorlanadi. Avtomatik (background) SMS yuborish uchun SMS-xizmat (masalan Eskiz.uz) ulanishi kerak.</p>
  `;
  openModal('modal-debt');
}

async function markDebtPaid(saleId) {
  const s = sales.find(x => x.id === saleId);
  if (!s) return;
  s.paid = true;
  await saveData('sales', sales);
  closeModal('modal-debt');
  renderDebts();
  renderRecentSales();
  showToast('Nasiya to\'langan deb belgilandi');
}

// ===================== DUE DEBT NOTIFICATION (in-app reminder) =====================
function checkDueDebtsAndNotify() {
  const todayStr = dateToStr(new Date());
  const dueToday = sales.filter(s => s.type === 'qarz' && !s.paid && daysBetween(todayStr, s.dueDate) <= 0);
  if (dueToday.length > 0) {
    showToast(`Diqqat: ${dueToday.length} ta nasiya muddati tugadi yoki bugun tugaydi`);
  }
}

// ===================== QR SCANNER =====================
let html5QrCode = null;
let scanCallback = null;

function bindScanner() {
  // nothing extra needed here, opened on demand
}

function openScanner(onResult) {
  scanCallback = onResult;
  openModal('modal-scanner');
  setTimeout(startScanner, 200);
}

function startScanner() {
  if (typeof Html5Qrcode === 'undefined') {
    showToast('Skaner kutubxonasi yuklanmadi. Internetni tekshiring.');
    return;
  }
  html5QrCode = new Html5Qrcode('qr-reader');
  const config = { fps: 10, qrbox: { width: 220, height: 220 } };
  html5QrCode.start(
    { facingMode: 'environment' },
    config,
    (decodedText) => {
      stopScanner();
      closeModal('modal-scanner');
      if (scanCallback) scanCallback(decodedText);
    },
    (errorMessage) => { /* ignore per-frame errors */ }
  ).catch((err) => {
    showToast('Kameraga ruxsat berilmadi yoki kamera topilmadi');
  });
}

function stopScanner() {
  if (html5QrCode) {
    html5QrCode.stop().then(() => {
      html5QrCode.clear();
      html5QrCode = null;
    }).catch(() => { html5QrCode = null; });
  }
}

// ===================== UTILS =====================
function escapeHtml(str) {
  if (str === undefined || str === null) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function dateToStr(d) {
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd}`;
}

function daysBetween(fromStr, toStr) {
  const from = new Date(fromStr);
  const to = new Date(toStr);
  return Math.round((to - from) / (1000 * 60 * 60 * 24));
}

function formatDate(dateStr) {
  const d = new Date(dateStr);
  const months = ['yan','fev','mart','apr','may','iyun','iyul','avg','sen','okt','noy','dek'];
  return `${d.getDate()} ${months[d.getMonth()]} ${d.getFullYear()}`;
}

function formatDateTime(dateStr) {
  const d = new Date(dateStr);
  const hh = String(d.getHours()).padStart(2,'0');
  const mi = String(d.getMinutes()).padStart(2,'0');
  return `${formatDate(dateStr)}, ${hh}:${mi}`;
}
